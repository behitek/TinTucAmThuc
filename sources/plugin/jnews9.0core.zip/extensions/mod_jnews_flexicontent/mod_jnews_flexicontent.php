<?php
defined('_JEXEC') or die('Access Denied!');
### Copyright © 2006-2016 Joobi Limited. All rights reserved.
### http://www.gnu.org/copyleft/gpl.html GNU/GPL

if(!defined('JNEWS_JPATH_ROOT')){
	if ( defined('JPATH_ROOT') AND class_exists('JFactory')) {	// joomla 15
		$mainframe = JFactory::getApplication();
		define ('JNEWS_JPATH_ROOT' , JPATH_ROOT );
	}
}

jimport('joomla.filesystem.file');
if ( strtolower( substr( JPATH_ROOT, strlen(JPATH_ROOT)-13 ) ) =='administrator' ) {
	$adminPath = strtolower( substr( JPATH_ROOT, strlen(JPATH_ROOT)-13 ) );
} else {
	$adminPath = JPATH_ROOT;
}
$mainAdminPathDefined = $adminPath .DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_jnews'.DIRECTORY_SEPARATOR.'defines.php';
if ( JFile::exists( $mainAdminPathDefined ) ) {
	require_once( $mainAdminPathDefined );
	
	//we check if jnews files exists
	//for jnews the main file is the class.jnews.php so we check if this file exists
	if ( JFile::exists(JNEWS_JPATH_ROOT .DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_jnews'.DIRECTORY_SEPARATOR.'classes'.DIRECTORY_SEPARATOR.'class.jnews.php')) {
		require_once(JNEWS_JPATH_ROOT .DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_jnews'.DIRECTORY_SEPARATOR.'classes'.DIRECTORY_SEPARATOR.'class.jnews.php');
	} else {
		die ("jNews Flexicontent Module\n<br />This module needs the jNews component.");
	}
	
	//we check if flexicontent files exists
	if ( JFile::exists(JNEWS_JPATH_ROOT .DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_flexicontent'.DIRECTORY_SEPARATOR.'admin.flexicontent.php')) {
		//require_once(JNEWS_JPATH_ROOT .DIRECTORY_SEPARATOR.'administrator'.DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_flexicontent'.DIRECTORY_SEPARATOR.'admin.flexicontent.php');
	} else {
		die ("jNews Flexicontent Module\n<br />This module needs the Flexicontent component.");
	}


	$js ="function setToSession(id, type, url){
				"; 
		if( version_compare(JVERSION,'1.6.0','<') ){//1.5
		$js .="
				var ajax = new Ajax(url,
 					{data: 'flexicontent_catid='+id+'&flexicontent_type='+type,
 					method: 'POST',
 					onComplete : function(result){}
 					}
 				);

 				ajax.request();";
		}else{
		$js.= "var ajax = new Request({
				url : url,
				data: 'flexicontent_catid='+id+'&flexicontent_type='+type,
				method: 'POST',
				onComplete : function(result){}
				});

				//we execute the http request
				ajax.send();";
		}
		
 		$js .= "


			}";
			
                                                
        $js .= 'function submitjnewsfleximod(formname, url){
        	var form = eval(\'document.\'+formname);';
        $js .= 'form.submit();' .
                                            'return true;}';
			

	$urlj = compajNews::completeLink( 'option=com_jnews&act=mailing&task=flexicontent', false, false, true );
	
	
	$doc =& JFactory::getDocument();
	$doc->addScriptDeclaration($js);
	
	//we get the parameters of the module here and assign them to a variable
	$height = $params->get('height', 200);
	$topLevelCategory = $params->get('topLevelCategory', 'current');
	$format = $params->get('format', 'vertical');
	$listid = $params->get('listid', 0);
	
	//we set the listid in the session
	$session =& JFactory::getSession();
 	$session->set('modjnewsflexi_listid', $listid,'JNEWLSETTER');
	
 	//initiallized html
		$html="";
		
		//check if what is the chosen top level category
		if($topLevelCategory == 'current') {
			$title = 'Current Tenders';
			$html .= '<h4>'.$title.'</h4>';
		}elseif($topLevelCategory == 'awarded') {
			$title = 'Awarded Tenders';
			$html .= '<h4>'.$title.'</h4>';
		}else {
			$title = 'Archived Tenders';
			$html .= '<h4>'.$title.'</h4>';
		} 

		$linkForm = 'index.php?option=com_jnews&act=flexicontentsubscribe';
		
		$html .='<form name="jnewsflexicontent_module" id="jnewsflexicontent_module" action="'.$linkForm.'" method="post">';
		
		$db=JFactory::getDBO();
		$query = 'SELECT id, title FROM `#__categories` WHERE `parent_id`=(SELECT `id` FROM `#__categories` WHERE `title`=\'Countries\' AND ';
		$query .= '`parent_id`=(SELECT `id` FROM `#__categories` WHERE `title`=\''.$title.'\')';
		$query .= ')  AND `published`=1 ORDER BY `title` ';
		$db->setQuery($query);
		$countriesA = $db->loadObjectList();
		
		$query = 'SELECT id, title FROM `#__categories` WHERE `parent_id`=(SELECT `id` FROM `#__categories` WHERE `title`=\'Industries\' AND ';
		$query .= '`parent_id`=(SELECT `id` FROM `#__categories` WHERE `title`=\''.$title.'\')';
		$query .= ') AND `published`=1 ORDER BY `title` ';
		$db->setQuery($query);
		$industriesA = $db->loadObjectList();

		if(!empty($countriesA)){
			$html .= '<div>';
			$html .= 'Select Countries:';
			$html .= '<div style="width:100%;height:'.$height.'px;border:solid 1px;overflow-y:scroll;">';
		
			foreach( $countriesA as $country ){
			
				$html .= '<input type="checkbox" name="category_'.$country->id.'" id="category_'.$country->id.'" value="'.$country->id.'" onclick="setToSession(\''.$country->id.'\', \'country\', \''.$urlj.'\')">';
				$html .= $country->title;
				$html .= '<br>';
			
			}
		
			$html .= '</div>';
			$html .= '</div>';
		}
		
		if($format == 'vertical') $html .= '<br/>';
		
		if(!empty($industriesA)){
			$html .= '<div>';
			$html .= 'Select Industries:';
			$html .= '<div style="width:100%;height:'.$height.'px;border:solid 1px;overflow-y:scroll;">';
		
			foreach( $industriesA as $industry ){
			
				$html .= '<input type="checkbox" name="category_'.$industry->id.'" id="category_'.$industry->id.'" value="'.$industry->id.'" onclick="setToSession(\''.$industry->id.'\',\'industry\', \''.$urlj.'\')">';
				$html .= $industry->title;
				$html .= '<br>';
			
			}
		}
		
		$html .= '</div>';
		$html .= '</div>';
		
		$html .= '<br/><input type="button" class="button" name="Subscribe" value="Subscribe" onclick="return submitjnewsfleximod(\'jnewsflexicontent_module\',\'\')">';
		
		$html .='</form>';
		
		//display html	
		echo $html;
		
 
}//if
