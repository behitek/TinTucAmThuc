<?php
defined('_JEXEC') OR die('Access Denied!');
### Copyright © 2006-2016 Joobi Limited. All rights reserved.
### http://www.gnu.org/copyleft/gpl.html GNU/GPL

JApplication::registerEvent('jnewsbot_transformall', 'jnewsbot_loadSmartFlexiContent_transformall' );


/**
	 * //function to replace the smartflexi tag with the articles from the section ids that we get from the params, where published from the lastDate
	 * @param - serialized, base64 params
	 * @param - lastDate, lastDate of the articles being retrieved
	 * @param - content content of the newsletter
	 * */
	function jnewsbot_loadSmartFlexiContent_transformall( &$content, &$textonly, &$subject, $queueInfo=null ){
		
		if ( empty($queueInfo) || empty($content) ) return true;
		
		//we check if the tag for the flexicontent is in the smartnewsletter
        $pos = strpos($content, '[SMARTFLEXI]');
        if($pos !== false) {
        	//we get the subscribers params from the queueinfo
        	$params = $queueInfo->qparams;

        	//we unserialize and decode the params so that we can get the category ids for the countries and industries
			$paramsCategoriesO = unserialize(base64_decode($params));

			if ( !empty($paramsCategoriesO->country) ) $countryCat = implode(',', $paramsCategoriesO->country );
        	if ( !empty($paramsCategoriesO->industry) ) $industryCat = implode(',',  $paramsCategoriesO->industry );

        	if ( empty($countryCat) && empty($industryCat) ) {
//        		$content = '';	//there is not article for that choice of category so we empty the content so that we dont send the newsletter
//				$textonly = '';
				$subject = '';
				return true;
        	};
        	
        	$plugin =& JPluginHelper::getPlugin('jnews', 'flexicontent');
			$pluginparams = json_decode( $plugin->params );
		
			$contentRendering = $pluginparams->get('contentrendering');
			$lastDate = $queueInfo->qdelay;
        	
       		 //and if there is we call the plugin of jomsocial which is also integrated with flexicontent
			$db=JFactory::getDBO();

        	
			$query = 'SELECT A.`itemid` AS `id`, C.`title`, C.`introtext`, C.`fulltext`, C.`images`, C.`created_by_alias` FROM `#__flexicontent_cats_item_relations` as A';
			$query .= ' LEFT JOIN `#__flexicontent_cats_item_relations` as B on A.`itemid` = B.`itemid` ';
			$query .= ' LEFT JOIN `#__content` as C on A.`itemid` = C.`id`';
			
			$query .= ' WHERE (';
		    if( !empty($countryCat) ) $query .= ' A.`catid` IN( '.$countryCat.') ';
		    if( !empty($countryCat) && !empty($industryCat) ) $query .= ' AND ';
		    if( !empty($industryCat) ) $query .= ' B.`catid` IN('.$industryCat.')';
		    $query .= ')';
		    
		    $query .= ' AND ( C.`publish_up` >\''.jnews::getDBDate($lastDate).'\'';
			//$query .= ' OR `modified` > \''.jnews::getDBDate($lastDate).'\'';
			$query .= ' OR C.`created` >\''.jnews::getDBDate($lastDate).'\' )';
			$query .= ' AND C.`created` < \'' .jnews::getDBDate() .'\'';
			$query .= ' AND C.`publish_up` < \'' .jnews::getDBDate() .'\'';
			$query .= ' AND (C.`publish_down` > \''.jnews::getDBDate() .'\' OR C.`publish_down` = 0)';
			$query .= ' AND C.`state` = 1';
		    
		    $query .= ' GROUP BY A.`itemid` DESC ';
		    $query .= ' ORDER BY C.`created` DESC ';

			$db->setQuery($query);
		    $newsLists = $db->loadObjectList();

		    if(empty($newsLists)){
//				$content = '';	//there is not article for that choice of category so we empty the content so that we dont send the newsletter
//				$textonly = '';
				$subject = '';
			}else{
				require_once( JNEWSPATH_CLASS . 'content.php');
				$convertContent = new jNews_Content;
				
//				$FlexiContent = '';
				$FlexiContent = $convertContent->convertAndLayout( $newsLists, 1, true );

				//replace [SMARTFLEXI] with the converted layout of the retrieved articles
				$content = str_replace('[SMARTFLEXI]', $FlexiContent , $content );
			}
			
		}//endiif
		return true;
	}
		