<?php
defined('_JEXEC') OR die('Access Denied!');
### Copyright © 2006-2016 Joobi Limited. All rights reserved.
### http://www.gnu.org/copyleft/gpl.html GNU/GPL

if ( !defined('JNEWS_JPATH_ROOT') ) {
	require_once( JPATH_ROOT .DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_jnews'.DIRECTORY_SEPARATOR.'defines.php');
}

if( version_compare( JVERSION,'3.0.0','<' ) ) {
	JHTML::_('behavior.mootools');
} else {
	JHtmlBehavior::framework();
}

if ( strtolower( substr( JPATH_ROOT, strlen(JPATH_ROOT)-13 ) ) =='administrator' ) {	// joomla 15
	$adminPath = strtolower( substr( JPATH_ROOT, strlen(JPATH_ROOT)-13 ) );
} else {
	$adminPath = JPATH_ROOT;
}

$mainAdminPathDefined = $adminPath .DIRECTORY_SEPARATOR.'components'.DIRECTORY_SEPARATOR.'com_jnews'.DIRECTORY_SEPARATOR.'defines.php';
if ( JFile::exists( $mainAdminPathDefined ) ) {
	require_once( $mainAdminPathDefined );

	JApplication::registerEvent( 'jnewsbot_blog_editabs', 'jnewsbot_blog_editab' );
	JApplication::registerEvent( 'jnewsbot_transformall', 'jnewsbot_blog_transformall' );
}

function jnewsbot_blog_editab() {
 	 $blogItems = jnewsbot_blog_getitems();
 	 ob_start();
 	 $js = "function setBlogTag(id, url){
var form = document.adminForm;
if(!form){
form = document.mosForm;
}
 	if(id!=null){
		for (i=0;i<form.blog_type.length;i++) {
			if (form.blog_type[i].checked) {
	var blog_type = form.blog_type[i].value;
}
		}
		//var tag = '{blogitem:' + id + '|' + blog_type + '}';
		var tag =  id;
		getBlog(id, blog_type, url);

		form.blogtag.value = tag;
	}else{
		//var tag = form.blogtag.value;
		var tag = form.blogreplace.value;
		if(window.top.insertTag(tag)){window.top.document.getElementById('sbox-window').close();}
	}

}

function getBlog(id, blog_type, url){
	var ajax = new Ajax(url,
		{data: 'blogId='+id+'&blog_type='+blog_type,
		method: 'POST',
		onComplete : function(result){insertBlog(result, id); }
		}
	);
	ajax.request();
}


function insertBlog(html, id){
	var form = document.adminForm;
	if(!form){
		form = document.mosForm;
	}

	var root = document.createElement('div');
	root.innerHTML = html;

        		// Get all child nodes of root div
        		var allChilds = root.childNodes;
        		// Loop through all the child nodes and check for id = 'head'
	for(var i = 0; i < allChilds.length; i++) {
            		// if id == 'head', you get your element
	   if (allChilds[i].id && allChilds[i].id == 'blogcontent_'+id) {
			form.blogreplace.value = allChilds[i].innerHTML;
          		 	}
	}
}
";
$url = JURI::root(). jNews_Tools::completeLink( 'option=com_jnews&act=mailing&task=blogContent', false, false, true );
$doc =& JFactory::getDocument();
$doc->addScriptDeclaration($js);
?>
<style type="text/css">
	table.smartcontent {
		border: 1px solid #D5D5D5;
		background-color: #F6F6F6;
		width: 100%;
		margin-bottom: 10px;
		-moz-border-radius:3px;
 		-webkit-border-radius:3px;
 		padding: 5px;
 	}
 	table.smartcontent td.key {
 		background-color: #f6f6f6;
		text-align: left;
		width: 140px;
		color: #666;
		font-weight: bold;
		border-bottom: 1px solid #e9e9e9;
		border-right: 1px solid #e9e9e9;
 	}
 </style>
<div id="element-box">
	<div class="t">
		<div class="t">
			<div class="t"></div>
		</div>
	</div>
<div class="m">	
<form name="adminForm" method="post" action="<?php echo jNews_Tools::completeLink( 'option=com_jnews', true, false, true ); ?>">
<table class="smartcontent" width="100%"">
	<tr>
		<td width="185" class="key">
			<span class="editlinktip">
			<?php
				$tip = _JNEWS_BLOG_TIPS;
				$title = _JNEWS_BLOG_RENDERING;
				echo jNews_Tools::toolTip( $tip, '', 280, 'tooltip.png', $title, '', 0 );
			?>
			</span>
		</td>
		<td style="vertical-align: top;">
				<span class="editlinktip">
			    <?php
				$tip =  _JNEWS_TITLE_ONLY_TIPS ;
            	$title = _JNEWS_TITLE_ONLY;
			   	$title_only = "<span class=\"editlinktip\">" . jNews_Tools::toolTip( $tip, '', 280, 'tooltip.png', $title, '', 0 ) . "</span>";

				//$tip = _JNEWS_INTRO_ONLY_TIPS;
				$title =  _JNEWS_INTRO_ONLY;
				$intro_only = "<span class=\"editlinktip\">" . jNews_Tools::toolTip( $tip, '', 280, 'tooltip.png', $title, '', 0 ) . "</span>";

           		$tip =  _JNEWS_FULL_ARTICLE_TIPS;
				$title =  _JNEWS_FULL_ARTICLE ;
				$full_article = "<span class=\"editlinktip\">" . jNews_Tools::toolTip( $tip, '', 280, 'tooltip.png', $title, '', 0 ) . "</span>";
				?>
				</span>
				<span class="editlinktip">
                <input type="radio" name="blog_type" value="0" checked="checked" /><?php echo 'Full Blog'/*$full_article*/; ?>
                <input type="radio" name="blog_type" value="1" /><?php echo 'Intro Only'; ?>
        <!--         <input type="radio" name="blog_type" value="2" /><?php //echo $title_only; ?> -->
                </span>

		</td>
		<td rowspan="2">
			<input onclick="setBlogTag(null,'<?php echo $url; ?>')" class="inserttag" type="button" label="Insert Blog" name="Insert Blog" value="Insert Blog"/>
		</td>
	</tr>
	<tr>
		<td width="185" class="key">
			<span class="editlinktip">
				<?php
				$tip =  _JNEWS_BLOG_TIP ;
            	$title = _JNEWS_BLOG_ID ;
			   	echo jNews_Tools::toolTip( $tip, '', 280, 'tooltip.png', $title, '', 0 );
				?>
			</span>
		</td>
		<td style="vertical-align: top;">
				<!--  <input type="text" onchange="setCaptionTags();" size="60px" name="jnewstagcaption"> -->
				<input type="text" size="60px" name="blogtag">
		</td>
	</tr>
	<tr>
		<td colspan="2">
			<input id="insertbot" type="hidden" size="60px" name="blogreplace" />
		</td>
	</tr>
</table>
<div id="element-box">
	<div class="t">
		<div class="t">
			<div class="t"></div>
		</div>
	</div>
<div class="m">
<table class="joobilist" cellpadding="0" cellspacing="0">
		<tbody>
			<thead>
				<tr>
					<th class="title">
						<?php echo 'TITLE'; ?>
					</th>
					<th width="80px" class="title">
						<?php echo 'Category'; ?>
					</th>
					<th width="30px" class="title">
						ID
					</th>
				</tr>
			</thead>
			<?php

				if(sizeof($blogItems) > 0){
					$k = 0;
					foreach($blogItems as $blogItem){
						//if (empty($blogItem->section)) $blogItem->section = JText::_('Uncategorised');
						if (empty($blogItem->category)) $blogItem->category = JText::_('Uncategorised');
						echo '<tr style="cursor:pointer" class="row'.$k.'" onclick="setBlogTag(\''.$blogItem->id.'\',\''.$url.'&blogId='.$blogItem->id.'\');" ><td>'.$blogItem->title.'</td><td nowrap="nowrap" align="center">'.$blogItem->category.'</td><td nowrap="nowrap" align="center">'.$blogItem->id.'</td></tr>';
						$k = 1-$k;
					}
				}
			?>
		</tbody>
</table>
</form>
	</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
</div>
	<div class="b">
		<div class="b">
			<div class="b"></div>
		</div>
	</div>
</div>
<?php
	 $return = ob_get_contents();
	 ob_end_clean();
	 return array(_JNEWS_CONTENT_ITEM, $return);
 }

 function jnewsbot_blog_getitems() {
//echo 'blog items';
		$db=JFactory::getDBO();
		//get the parameters from the plugin
		$plugin =& JPluginHelper::getPlugin('jnews', 'jnewsbotlyften');
		$params = json_decode( $plugin->params );
		//get the limit parameter
		$blog_limit = $params->get('blog_limit','0');
		$blog_order = $params->get('blog_order','0');
		$query = 'SELECT A.id as id, A.title as title, B.title as category FROM `#__bloggies_entries` as A LEFT JOIN `#__bloggies_categories` as B ON A.catid = B.id';
		$query .= " WHERE A.state = 1";
		if($blog_order == 0){
			$query .= ' ORDER BY B.title ASC ';
		}elseif($blog_order == 2){
			$query .= ' ORDER BY A.created ASC ';
		}elseif($blog_order == 1){
			$query .= ' ORDER BY A.modified ASC ';
		}else{
			$query .= ' ORDER BY A.title ASC ';
		}
		$query .= ' LIMIT ' . (int)$blog_limit;

		$db->setQuery($query);
	 	$blogitems = $db->loadObjectList();
	 return $blogitems;
 }

 function jnewsbot_blog_transformall($html, $text, $subject, $queueInfo=null ) {
	 $mainframe =& JFactory::getApplication();

 	 $blog_items = array();
	 preg_match_all('/\{blogitem:(.{1,8})\|(.{1})}/', $html, $blog_items, PREG_SET_ORDER);
	 foreach ($blog_items as $blog_item) {

		 
		 if( version_compare(JVERSION,'1.6.0','<') ) $Itemid = $mainframe->getItemId($blog_item[1]);

		 if(empty($Itemid)){
		 	$Itemid = $GLOBALS[JNEWS.'itemidAca'];
		 }
		 $replacement = jnewsbot_blog_getitem($blog_item[1]);
		 if ($GLOBALS[JNEWS.'show_author'] == 1){
			$author = '<br />'.$replacement->created_by_alias;
		}
		else{
			$author = '';
		}
		 if ($blog_item[2] == 0) {
			 $html = str_replace($blog_item[0], '<div class="aca_content"><span class="aca_title">' . $replacement->title . '</span>' . "\r\n" . $author .'<br />' . $replacement->introtext . '<br />' . "\r\n" . $replacement->fulltext1 . "\r\n".'</div>', $html);
		 } else {

			$link = 'option=com_lyftenbloggie&view=lyftenbloggie&view=entry&id='.$blog_item[1].'&Itemid='.$Itemid;
			$link = jNews_Tools::completeLink($link,false,$GLOBALS[JNEWS.'use_sef']);

             if ($blog_item[2] == 1) {
             	if(empty($replacement->fulltext1) AND !empty($GLOBALS[JNEWS.'word_wrap'])){
             		//Limit the number of words
             		if(strlen($replacement->introtext) > $GLOBALS[JNEWS.'word_wrap']){
             			$fulltext1 = strip_tags($replacement->introtext,'<br><img>');
             			if(strlen($fulltext1) > $GLOBALS[JNEWS.'word_wrap']){
	             			//We make sure we won't cut any html tag :
	             			$open = 0;
	             			$limitText = strlen($fulltext1) - 1;
	             			for($i=0;$i<strlen($fulltext1);$i++){
	             				if($replacement->introtext[$i] == '<'){ $open++; continue;}
	             				if($replacement->introtext[$i] == '>'){$open--; continue;}
	             				if($replacement->introtext[$i] == " " AND $i>$GLOBALS[JNEWS.'word_wrap'] AND $open == 0){
	             					$limitText = $i-1;
	             					break;
	             				}
	             			}
	             			$replacement->introtext = substr($fulltext1,0,$limitText).'...';
             			}
             		}
             	}
			    $html = str_replace($blog_item[0], '<div class="aca_content"><span class="aca_title">' . $replacement->title . '</span>' . "\r\n" . $author . '<br />' . $replacement->introtext . '<br />' . "\r\n" . '<a href="' . $link . '"><span class="aca_readmore">' . _JNEWS_READMORE . '</span></a>' . "\r\n".'</div>', $html);
             }
             else {
			    $html = str_replace($blog_item[0], '<a href="' . $link . '"><span class="aca_title">' . $replacement->title . '</span></a>', $html);
             }
        }

		 $images = jnewsbot_blog_getimage($replacement->images);
		 foreach($images as $image) {
			 $image_string = '<img src="' . JNEWS_JPATH_LIVE_NO_HTTPS . '/images/stories/' . $image['image'] . '" align="' . $image['align'] . '" alt="' . $image['alttext'] . '" border="' . $image['border'] . '" />';
			 $html = preg_replace('/{mosimage}/', $image_string, $html, 1);
		 }
	 }
	 $blog_items = array();
	 preg_match_all('/\{blogitem:(.{1,5})\|(.{1})}/', $text, $blog_items, PREG_SET_ORDER);
	 foreach ($blog_items as $blog_item) {

		 
		 if( version_compare(JVERSION,'1.6.0','<') ) $Itemid = $mainframe->getItemId($blog_item[1]);

		 if(empty($Itemid)){
		 	$Itemid = $GLOBALS[JNEWS.'itemidAca'];
		 }
		 $replacement = jnewsbot_blog_getitem($blog_item[1]);
 		if ($GLOBALS[JNEWS.'show_author'] == 1){
		 	$author = "\r\n".$replacement->created_by_alias;
	 	}
	 	else{
	 		$author = '';
	 	}

		 $replacement->title ="<b>". strtoupper(jNews_ProcessMail::htmlToText($replacement->title)) ."</b>";
		 $replacement->introtext = jNews_ProcessMail::htmlToText($replacement->introtext);
		 $replacement->fulltext1 = jNews_ProcessMail::htmlToText($replacement->fulltext1);
		 if ($blog_item[2] == 0) {
			 $text = str_replace($blog_item[0], $replacement->title . $author . "\r\n" . $replacement->introtext . "\r\n" . $replacement->fulltext1 . "\r\n", $text);
		 } else {

		 	$link = 'option=com_lyftenbloggie&view=lyftenbloggie&view=entry&id='.$blog_item[1].'&Itemid='.$Itemid;
		 	$link = jNews_Tools::completeLink($link,false,$GLOBALS[JNEWS.'use_sef']);

             if ($blog_item[2] == 1) {
				if(empty($replacement->fulltext1) AND !empty($GLOBALS[JNEWS.'word_wrap'])){
             		if(strlen($replacement->introtext) > $GLOBALS[JNEWS.'word_wrap']){
             			$replacement->introtext = substr(strip_tags($replacement->introtext),0,$GLOBALS[JNEWS.'word_wrap']).'...';
             		}
             	}
			    $text = str_replace($blog_item[0], $replacement->title . $author . "\r\n" . $replacement->introtext . "\r\n" . '* ' . _JNEWS_READMORE . ' ( '. $link . ' )' . "\r\n", $text);
             }
             else {
			    $text = str_replace($blog_item[0], $replacement->title . ' ( ' . $link . ' )', $text);
             }
         }
		 $text = str_replace('{mosimage}', '', $text);
	 }

	 $html = str_replace('{mospagebreak}', '<div style="clear: both;" ></div>', $html);
	 $text = str_replace('{mospagebreak}', "\r\n \r\n", $text);

 }


 function jnewsbot_blog_getitem($id) {
	$db=JFactory::getDBO();
	$query = "SELECT A.id as id, A.fulltext as fulltext1, A.title as title, B.title as category, A.introtext as introtext, A.created_by_alias as created_by_alias, A.images as images FROM `#__bloggies_entries` as A LEFT JOIN `#__bloggies_categories` as B ON A.catid = B.id WHERE A.id = $id";
	$db->setQuery($query);
	$blog_item = $db->loadObject();

	if($blog_item->created_by_alias == ''){$blog_item->created_by_alias = $blog_item->created_by_alias;}

	if(get_magic_quotes_runtime()) {
		$blog_item->title ="<b>". stripslashes($blog_item->title)."</b>";
		$blog_item->introtext = stripslashes($blog_item->introtext);
		$blog_item->fulltext1 = stripslashes($blog_item->fulltext1);
		$blog_item->images = stripslashes($blog_item->images);
		$blog_item->created_by_alias = stripslashes($blog_item->created_by_alias);
	}

	return $blog_item;
 }

 function jnewsbot_blog_getimage($images) {

	$first = @explode("\n",$images);

	for($i=0, $n=count($first); $i < $n; $i++) {
		$second = explode('|',$first[$i] . '|||');
		$third[$i]['image'] = $second[0];
		$third[$i]['align'] = $second[1];
		$third[$i]['alttext'] = $second[2];
		$third[$i]['border'] = $second[3];
	}
	return $third;
 }
