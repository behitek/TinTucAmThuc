<?php

defined('_JEXEC') OR die('Access Denied!');
putenv('GDFONTPATH=' . realpath('.'));
### © 2006-2016 Joobi Limited. All rights reserved.
### license GNU GPLv3 , link https://joobi.co

 /** Created on 11 24, 09
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
$width = JRequest::getInt( 'width', 60 );
$height = JRequest::getInt( 'height', 30 );
$bgcolor = JRequest::getString( 'bgcolor', '' );
$ftcolor = JRequest::getString( 'ftcolor', '' );
$characters = JRequest::getInt( 'characters', 5 );
if ( $characters < 4 ) $characters = 5;
$esc = jnews::getVar('esc' );
$encpwd = jnews::getVar('encpwd' );

CaptchaSecurityImages( $width, $height, $characters, $esc, $encpwd, $bgcolor, $ftcolor );

	function decryptData($encoded_text, $password) {
		if(empty($key)){
			$key='';
		}
		
		if ( !function_exists('mcrypt_get_iv_size') ){
	 		return 0;
	 		echo 'mcrypt_get_iv_size is not enabled. Kindly enable this extension in your php.ini file.';
	 	} 
		
		$iv_size = ( function_exists('mcrypt_get_iv_size') ) ? mcrypt_get_iv_size(MCRYPT_XTEA, MCRYPT_MODE_ECB) : 8;
	    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
	    $original = trim(mcrypt_decrypt(MCRYPT_XTEA, $key, base64_decode($encoded_text), MCRYPT_MODE_ECB, $iv), "\0");
	    return $original;
	  }

	function CaptchaSecurityImages( $width, $height, $characters, $esc, $encpwd, $bgcolor, $ftcolor ) {

		/* Decoding the security_code*/
    	$code = decryptData($esc, $encpwd);
		$font_size = $height * 0.80;
		$image = @imagecreate($width, $height) or die('Cannot initialize new GD image stream');
		/* set the colours */
		
		if ( !empty($bgcolor) ) {
			$newColorA = CaptchaSecurityImagesHTML2rgb( $bgcolor );
			$c1 = $newColorA[0];
			$c2 = $newColorA[1];
			$c3 = $newColorA[2];
		} else {
	   		$c1 = mt_rand(50,200); //r(ed)
	     	$c2 = mt_rand(50,200); //g(reen)
	     	$c3 = mt_rand(50,200); //b(lue)			
		}

     	
	     //test if we have used up palette
	     if(imagecolorstotal($image)>=255) {
	          //palette used up; pick closest assigned color
	          $background_color = imagecolorallocate($image, $c1, $c2, $c3);
	     } else {
	          //palette NOT used up; assign new color
	         $background_color = imagecolorallocate($image, $c1, $c2, $c3);
	     }
	     
	     if ( !empty($ftcolor) ) {
	     	$newColorA = CaptchaSecurityImagesHTML2rgb( $ftcolor );
			$c1 = $newColorA[0];
			$c2 = $newColorA[1];
			$c3 = $newColorA[2];
	     } else {
	     	$c1 = 0;
	     	$c2 = 0;
	     	$c3 = mt_rand(50,200);
	     }
	     
		$text_color = imagecolorallocate($image, $c1, $c2, $c3 );
		$noise_color = imagecolorallocate($image, 253, 250, 250);
		/* generate random dots in background */
		for( $i=0; $i<($width*$height)/3; $i++ ) {
			imagefilledellipse($image, mt_rand(0,$width), mt_rand(0,$height), 1, 1, $noise_color);
		}
		/* generate random lines in background */
		for( $i=0; $i<($width*$height)/150; $i++ ) {
			imageline($image, mt_rand(0,$width), mt_rand(0,$height), mt_rand(0,$width), mt_rand(0,$height), $noise_color);
		}
		/* create textbox and add text */

		$textbox = imagettfbbox($font_size, 0, JNEWSPATH_FRONT.'captcha_version1'.DIRECTORY_SEPARATOR.'monofont.ttf', $code) or die('Error in imagettfbbox function');
		$x = ($width - $textbox[4])/2;
		$y = ($height - $textbox[5])/2;
		imagettftext($image, $font_size, 0, $x, $y, $text_color, JNEWSPATH_FRONT.'captcha_version1'.DIRECTORY_SEPARATOR.'monofont.ttf' , $code) or die('Error in imagettftext function');
		ob_end_clean();
		/* output captcha image to browser */
    	header('Content-Type: image/jpeg');
		imagejpeg($image);
		imagedestroy($image);
		exit;
	}
	
	function CaptchaSecurityImagesHTML2rgb($color) {
	    if ($color[0] == '#')
	        $color = substr($color, 1);
	
	    if (strlen($color) == 6)
	        list($r, $g, $b) = array($color[0].$color[1],
	                                 $color[2].$color[3],
	                                 $color[4].$color[5]);
	    elseif (strlen($color) == 3)
	        list($r, $g, $b) = array($color[0].$color[0], $color[1].$color[1], $color[2].$color[2]);
	    else
	        return false;
	
	    $r = hexdec($r); $g = hexdec($g); $b = hexdec($b);
	
	    return array($r, $g, $b);
	}